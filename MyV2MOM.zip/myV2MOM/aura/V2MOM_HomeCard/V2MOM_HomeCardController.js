({
	showQuarterValues : function(component, event, helper) {
		component.set('v.showQuarterDetails', true);
	},
    hideQuarterValues : function(component, event, helper) {
        component.set('v.showQuarterDetails', false);
    }
})